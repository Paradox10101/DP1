# odiparpack-gls
main algorithm
